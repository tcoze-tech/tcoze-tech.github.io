---
name: prd-json-draft
description: 按本仓库 src/types/prd.ts 的 PrdDraft 结构，为单个业务模块生成一份完整、可回填/导入 prd-create 生成器的 PRD 内容 JSON（含 basic、terms、roles、features、pages、entities、apis、states、rules、checklist、risks、nfr、sectionsEnabled），从而渲染为标准 Markdown PRD。当需要根据需求产出、补全或校验「模块 PRD 内容 JSON / 结构化 PRD 草稿」，或要求输出符合 prd-create 数据结构的数据时使用。
---

# PRD 内容 JSON 生成规范

## 目标

根据一段业务需求描述，输出一个「单业务模块」的结构化 PRD 内容 JSON。
该 JSON 是 prd-create 工具可识别的草稿结构（等价于 `src/types/prd.ts` 中的 `PrdDraft`），
可以被回填到生成器的表单/草稿，或经「工程文件」包装后导入，进而渲染成标准 Markdown PRD。

## 何时使用

- 用户要求"生成某模块的 PRD"、"产出 JSON 草稿"、"给一段 JSON 数据/演示数据"；
- 需要按本仓库数据结构（`PrdDraft`）输出内容，而不是直接写 Markdown 正文时；
- 需要补全、修正或校验某模块的 PRD 结构化 JSON 时。

## 数据来源与事实基准

开始前先确认以下文件作为唯一事实来源，避免字段名/枚举臆造：

- 类型定义：`src/types/prd.ts`
- 章节与渲染顺序：`src/config/sections.ts`、`src/utils/markdown.ts`
- 默认值/演示样例：`src/stores/prd.ts`（`defaultData()`、`demoData()`）
- 字段级规范与完整示例：`references/schema.md`、`references/example.json`

## 工作流程

1. **提炼需求范围**：明确这是哪一个业务模块（模块名称/编码/边界）。"模块"指单一业务模块；若一次要求多个模块，应逐个分别产出，不混合进同一份 JSON。
2. **读取引用**：打开 `references/schema.md` 核对字段，参考 `references/example.json` 的写法和详略程度。
3. **逐章节生成内容**：按 schema.md 中「章节顺序」依次构思内容：功能需求 → 数据模型 → 接口设计 → 页面与交互 → 角色与权限 → 术语表 → 业务规则与状态机 → 非功能需求 → 验收清单与风险。
   - 章节顺序与 `sections.ts` 一致（features → datamodel → api → pages → roles → terms → rules → nfr → checklist）。
   - 内容相互呼应：角色权限 ↔ 功能/页面操作；状态流转 ↔ 实体状态枚举 ↔ 页面/接口；验收清单 ↔ 功能验收标准。
4. **结构自查**：对照下方「必检清单」逐条核对后再输出。
5. **输出**：仅输出 JSON 对象本身。对话场景可用 ```json 代码块包裹；若要求写入文件，则写入 `<模块名>.draft.json`。

## 输出格式要求

- 顶层必须包含 13 个键：`basic`、`terms`、`roles`、`features`、`pages`、`entities`、`apis`、`states`、`rules`、`checklist`、`risks`、`nfr`、`sectionsEnabled`。
- 行对象的键必须与类型定义**完全同名同构**，不得使用近似键（如 `desc` 写成 `description`、`reqExample` 写成 `requestExample`），不得混入额外字段。
- 字符串型字段一律输出字符串；布尔型（`required`、`sectionsEnabled` 值）输出 `true`/`false`；数组型字段输出数组。
- 凡"暂无内容"的字符串字段一律用空串 `""` 占位，**不要省略键、不要输出 `null`/`undefined`**；无条目的数组输出 `[]`。
- 产出默认是 `PrdDraft`（draft 级内容）。仅当用户明确要求「可直接导入工具的 .prd.json 工程文件」时，才在外层套壳：

```json
{
  "app": "prd-create",
  "formatVersion": 1,
  "exportedAt": "<当前 ISO8601 时间>",
  "moduleName": "<与 draft.basic.moduleName 一致>",
  "draft": { "<以上 13 键的完整内容>" }
}
```

## 内容质量规范

- 全程中文撰写（术语/代码字段等保留英文原文）。
- 只描述模块边界（`inScope`）内的内容，边界外（`outScope`）不展开细节。
- `basic`：`moduleName` 必填；`docDate` 用 `YYYY-MM-DD`；`version` 默认 `v1.0`；`owner` 建议「姓名（角色）」。
- 列表条目数控制在信息完整即可，不要为了"多"而注水；每条说明都要可执行、无歧义。
- `features`：`name` 用动宾短语；`priority` 仅限 `P0`/`P1`/`P2`/`P3`/`P4`（P0=核心链路）；`acceptance` 为字符串数组，每条一项可验证的标准。
- `apis`：`method` 用大写 HTTP 方法（GET/POST/PUT/PATCH/DELETE）；`path` 以 `/` 开头；`reqExample`/`respExample` 字段的内容是**字符串**，内部再放一段合法 JSON 文本——换行用转义 `\n`、双引号用转义 `\"`，并保持 JSON 本身合法。
- `entities[].fields[]`：`required` 为布尔；`enumValues` 用「值+含义」按 `/` 分隔的写法（如 `0待支付/1已支付`）；无枚举则空串。
- `states`：每条为一次状态迁移 `current → event → next`，事件要具体（谁/什么动作触发）。
- `nfr`：按 性能/安全/兼容性/数据量 等分类输出；模块不涉及的分类可不列出。
- `sectionsEnabled`：默认全部 `true`；某章节确实无内容或用户要求精简时，对应码设为 `false`。

## 必检清单

- [ ] 顶层 13 键齐全；`basic` 9 个键齐全（moduleName / moduleCode / version / owner / docDate / status / background / goal / inScope / outScope）。
- [ ] 行对象字段名与 `schema.md` 完全一致，无多余键、无缺键。
- [ ] 枚举合法：`priority ∈ {P0..P4}`；`method` 为大写 HTTP 方法；`required`/`sectionsEnabled` 为布尔。
- [ ] 嵌套数组完整：`features[].acceptance` 为 `string[]`；`entities[].fields` 为字段对象数组。
- [ ] 空值占位：所有字符串空字段为 `""`，全文件无 `null`。
- [ ] JSON 语法合法（可整体 `JSON.parse` 通过），含示例代码的字段转义正确。
- [ ] `sectionsEnabled` 的码为：terms / roles / features / pages / datamodel / api / rules / nfr / checklist。

## 引用文件

- `references/schema.md`：逐章节字段规范（键名、类型、含义、示例）
- `references/example.json`：一份完整可导入的示例草稿（建议先模仿其详略与连贯度）
