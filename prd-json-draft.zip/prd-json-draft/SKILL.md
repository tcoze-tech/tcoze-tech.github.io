---
name: prd-json-draft
description: 为单个业务模块生成 prd-create 工具「可直接导入」的 PRD 工程文件 JSON（顶层 app=prd-create / formatVersion / exportedAt / moduleName / draft；draft 内含 basic、terms、roles、features、pages、entities、apis、states、rules、checklist、risks、nfr、sectionsEnabled），导入后即可渲染为标准 Markdown PRD。完整格式定义内置于本 skill 的 references/format.md，使用时无需访问项目源码。当需要根据需求产出、补全或校验「模块 PRD 工程文件 JSON / 结构化 PRD 草稿」时使用。
---

# PRD 内容 JSON 生成规范

## 目标

根据一段业务需求描述，输出一个「单业务模块」的 **prd-create 工程文件 JSON**（完整格式定义见 `references/format.md`）。

**必须严格输出工程文件格式**：顶层 5 个元信息键 + `draft`（内含 13 个键的 `PrdDraft`），
结构见 `references/format.md` 第 1 节，校验规则见第 2 节。
工具导入时只认这一种结构；把 13 个内容键直接放在顶层的**裸 `PrdDraft` 无法导入**，
会提示「该文件不是本工具导出的 PRD 工程文件」。

## 何时使用

- 用户要求"生成某模块的 PRD"、"产出 JSON 草稿"、"给一段 JSON 数据/演示数据"；
- 需要按 prd-create 的 `PrdDraft` 数据结构输出内容，而不是直接写 Markdown 正文时；
- 需要补全、修正或校验某模块的 PRD 结构化 JSON 时。

## 数据来源与事实基准（自包含，无需源码）

**本 skill 自带规范即为唯一事实来源**，使用者无需访问 prd-create 项目源码：

- 格式定义（权威契约）：`references/format.md` —— 顶层结构、导入校验规则、TypeScript 等价类型、13 键定义、章节顺序、默认值
- 撰写规范与详略参考：`references/schema.md`、`references/example.json`

仅当本地恰好存在仓库时，可用以下文件**交叉核对**（可选，不是必需步骤）：
`src/types/prd.ts`、`src/utils/projectFile.ts`、`src/config/sections.ts`、`src/stores/prd.ts`。

## 导入校验硬约束（完整定义见 `references/format.md` 第 2 节）

工具导入时依次做以下校验，任一不通过即报错。生成结果**必须**满足：

| 顺序 | 校验规则 | 不满足时的报错 |
| --- | --- | --- |
| 1 | 文件可被 `JSON.parse` 解析 | 文件不是有效的 JSON，无法导入 |
| 2 | 解析结果是对象（非数组、非 null） | 文件内容不是有效的 JSON 对象 |
| 3 | `app` **严格等于**字符串 `"prd-create"`（区分大小写，不可写成 `prd_create`/`PRD-Create`/`prdCreate`） | 该文件不是本工具导出的 PRD 工程文件 |
| 4 | `draft` 存在且是对象 | 工程文件缺少 draft 数据，可能已损坏 |
| 5 | `draft.basic` 是对象，且 `draft.basic.moduleName` 是字符串 | 工程文件结构不完整，可能不是由本工具导出的 |

补充：`formatVersion` 固定输出数字 `1`（当前 `PROJECT_FORMAT_VERSION`）；若大于 1 工具会提示「由更新版本导出」。

## 工作流程

1. **提炼需求范围**：明确这是哪一个业务模块（模块名称/编码/边界）。"模块"指单一业务模块；若一次要求多个模块，应逐个分别产出，不混合进同一份 JSON。
2. **读取引用**：打开 `references/format.md` 核对结构契约（顶层 5 键、13 键定义、枚举、校验规则），再参考 `references/schema.md` 与 `references/example.json` 的写法和详略程度。
3. **逐章节生成内容**：按 schema.md 中「章节顺序」依次构思内容：功能需求 → 数据模型 → 接口设计 → 页面与交互 → 角色与权限 → 术语表 → 业务规则与状态机 → 非功能需求 → 验收清单与风险。
   - 章节顺序见 `references/format.md` 第 5 节（features → datamodel → api → pages → roles → terms → rules → nfr → checklist）。
   - 内容相互呼应：角色权限 ↔ 功能/页面操作；状态流转 ↔ 实体状态枚举 ↔ 页面/接口；验收清单 ↔ 功能验收标准。
4. **结构自查**：对照下方「必检清单」逐条核对后再输出。
5. **套工程外壳**：把 13 键的 `PrdDraft` 整体放进 `draft`，并在顶层补齐 `app`/`formatVersion`/`exportedAt`/`moduleName` 四个元信息键（`moduleName` 取 `draft.basic.moduleName`）。
6. **输出**：仅输出 JSON 对象本身。对话场景用 ```json 代码块包裹；若要求写入文件，文件名用 `<模块名>-<YYYYMMDD>.prd.json`（与工具导出命名一致，**不使用 `.draft.json`**）。

## 输出格式要求

顶层**固定且只能**是这 5 个键（顺序如下），`draft` 内才是 13 键的 `PrdDraft`：

```json
{
  "app": "prd-create",
  "formatVersion": 1,
  "exportedAt": "<当前 ISO8601 UTC 时间，如 2026-09-04T07:30:00.000Z>",
  "moduleName": "<与 draft.basic.moduleName 逐字一致>",
  "draft": {
    "basic": {},
    "terms": [],
    "roles": [],
    "features": [],
    "pages": [],
    "entities": [],
    "apis": [],
    "states": [],
    "rules": [],
    "checklist": [],
    "risks": [],
    "nfr": [],
    "sectionsEnabled": {}
  }
}
```

- 顶层元信息：`app` 固定字符串 `"prd-create"`；`formatVersion` 固定数字 `1`（**不是字符串**）；
  `exportedAt` 为 ISO8601 UTC 时间字符串（`new Date().toISOString()` 形式，带毫秒与 `Z`）；
  `moduleName` **必须与 `draft.basic.moduleName` 完全相等**，不能为空、不能加前后缀。
- `draft` 内 13 个键一个都不能少：`basic`、`terms`、`roles`、`features`、`pages`、`entities`、`apis`、`states`、`rules`、`checklist`、`risks`、`nfr`、`sectionsEnabled`。
- **禁止**把 `basic`/`features` 等内容键提到顶层（那会退化成裸 `PrdDraft`，工具无法导入）；也**禁止**在顶层增加第 6 个键。
- 行对象的键必须与类型定义**完全同名同构**，不得使用近似键（如 `desc` 写成 `description`、`reqExample` 写成 `requestExample`），不得混入额外字段。
- 字符串型字段一律输出字符串；布尔型（`required`、`sectionsEnabled` 值）输出 `true`/`false`；数组型字段输出数组。
- 凡"暂无内容"的字符串字段一律用空串 `""` 占位，**不要省略键、不要输出 `null`/`undefined`**；无条目的数组输出 `[]`。
- 文件名：`<模块名>-<YYYYMMDD>.prd.json`，例如 `店铺列表-20260904.prd.json`。
- 仅当用户**明确**说「只要 draft 内容、不要工程外壳」时，才输出裸 `PrdDraft`（顶层 13 键），并须同时提示「该文件不能被工具直接导入，需套工程外壳」。默认一律输出工程文件格式。

## 内容质量规范

- 全程中文撰写（术语/代码字段等保留英文原文）。
- 只描述模块边界（`inScope`）内的内容，边界外（`outScope`）不展开细节。
- `basic`：`moduleName` 必填；`docDate` 用 `YYYY-MM-DD`；`version` 默认 `v1.0`；`owner` 建议「姓名（角色）」。
- 列表条目数控制在信息完整即可，不要为了"多"而注水；每条说明都要可执行、无歧义。
- `features`：`name` 用动宾短语；`priority` 仅限 `P0`/`P1`/`P2`/`P3`/`P4`（P0=核心链路）；`acceptance` 为字符串数组，每条一项可验证的标准。
- `apis`：`method` 用大写 HTTP 方法（GET/POST/PUT/PATCH/DELETE）；`path` 以 `/` 开头；`reqExample`/`respExample` 字段的内容是**字符串**，内部再放一段合法 JSON 文本——换行用转义 `\n`、双引号用转义 `\"`，并保持 JSON 本身合法。
- `entities[].fields[]`：`required` 为布尔；`enumValues` 用「值+含义」按 `/` 分隔的写法（如 `0待支付/1已支付`）；无枚举则空串。
- `states`：每条为一次状态迁移 `current → event → next`，事件要具体（谁/什么动作触发）。
- `nfr`：按 性能/安全/兼容性/数据量 等分类输出；模块不涉及的分类可不列出。
- `sectionsEnabled`：默认全部 `true`；某章节确实无内容或用户要求精简时，对应码设为 `false`。

## 必检清单

- [ ] 顶层**恰好 5 键**：`app` / `formatVersion` / `exportedAt` / `moduleName` / `draft`，无多余键、无缺键。
- [ ] `app` 严格为 `"prd-create"`；`formatVersion` 为数字 `1`；`exportedAt` 为 ISO8601 字符串（含毫秒与 `Z`）。
- [ ] `moduleName` 与 `draft.basic.moduleName` 逐字一致。
- [ ] `draft` 存在且为对象；内部 13 键齐全。
- [ ] `draft.basic` 10 个键齐全（moduleName / moduleCode / version / owner / docDate / status / background / goal / inScope / outScope）。
- [ ] 行对象字段名与 `schema.md` 完全一致，无多余键、无缺键。
- [ ] 枚举合法：`priority ∈ {P0..P4}`；`method` 为大写 HTTP 方法；`required`/`sectionsEnabled` 为布尔。
- [ ] 嵌套数组完整：`features[].acceptance` 为 `string[]`；`entities[].fields` 为字段对象数组。
- [ ] 空值占位：所有字符串空字段为 `""`，无条目的数组为 `[]`，全文件无 `null`。
- [ ] JSON 语法合法（可整体 `JSON.parse` 通过），含示例代码的字段转义正确。
- [ ] `sectionsEnabled` 的码为：terms / roles / features / pages / datamodel / api / rules / nfr / checklist。
- [ ] **导入自测**：`obj.app === 'prd-create'` 且 `typeof obj.draft.basic.moduleName === 'string'` 均为真。

## 引用文件（全部自包含，无需项目源码）

- `references/format.md`：**权威格式定义**——顶层工程文件结构、导入校验规则与等价伪代码、TypeScript 类型定义、`draft` 13 键与行对象字段表、章节顺序与开关、默认值约定
- `references/schema.md`：工程文件顶层规范 + `draft` 内逐章节撰写规范（键名、类型、含义、示例）
- `references/example.json`：一份完整、可直接导入的工程文件示例（建议先模仿其详略与连贯度）
