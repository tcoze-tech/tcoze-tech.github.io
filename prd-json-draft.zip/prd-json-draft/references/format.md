# PRD 工程文件格式定义（自包含 · formatVersion = 1）

> **唯一事实来源**：本文件描述了 prd-create 工具导入所需的完整结构。
> 使用本 skill 时**不需要访问项目源码**；若本地恰好有仓库，可用
> `src/types/prd.ts`、`src/utils/projectFile.ts`、`src/config/sections.ts`、`src/stores/prd.ts`
> 交叉核对（可选，非必需）。

- 应用标识：`app = "prd-create"`
- 格式版本：`formatVersion = 1`
- 文件命名：`<模块名>-<YYYYMMDD>.prd.json`（与工具导出命名一致）
- 编码：UTF-8、无 BOM、2 空格缩进、中文不转义

---

## 1. 顶层结构（PrdProjectFile）

顶层**恰好 5 个键**，顺序如下；`draft` 内才是正文内容（13 个键）。

| 键 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `app` | string | 是 | 固定 `"prd-create"`，**严格区分大小写**（`prd_create`、`PRD-Create`、`prdCreate` 均会导入失败） |
| `formatVersion` | number | 是 | 固定数字 `1`，不可写成字符串 `"1"` |
| `exportedAt` | string | 是 | ISO8601 UTC 时间，如 `2026-09-04T08:22:11.989Z`（等价于 `new Date().toISOString()`） |
| `moduleName` | string | 是 | 模块名，**必须与 `draft.basic.moduleName` 逐字一致**，不可为空、不可加前后缀 |
| `draft` | object | 是 | 完整的 `PrdDraft`，含 13 个键，见第 3 节 |

最小可导入骨架：

```json
{
  "app": "prd-create",
  "formatVersion": 1,
  "exportedAt": "2026-09-04T08:22:11.989Z",
  "moduleName": "售后管理",
  "draft": {
    "basic": { "moduleName": "售后管理" },
    "terms": [],
    "roles": [],
    "features": [],
    "pages": [],
    "entities": [],
    "apis": [],
    "states": [],
    "rules": [],
    "checklist": [],
    "risks": [],
    "nfr": [],
    "sectionsEnabled": {}
  }
}
```

---

## 2. 导入校验规则（工具端硬校验）

工具按以下顺序校验，任一不通过即中止并提示：

| 顺序 | 条件 | 失败提示 |
| --- | --- | --- |
| 1 | `JSON.parse(text)` 成功 | 文件不是有效的 JSON，无法导入 |
| 2 | 结果是对象（非 `null`、非数组） | 文件内容不是有效的 JSON 对象 |
| 3 | `obj.app === "prd-create"` | **该文件不是本工具导出的 PRD 工程文件** |
| 4 | `obj.draft` 存在且是对象 | 工程文件缺少 draft 数据，可能已损坏 |
| 5 | `obj.draft.basic` 是对象且 `typeof obj.draft.basic.moduleName === "string"` | 工程文件结构不完整，可能不是由本工具导出的 |

等价伪代码：

```js
const obj = JSON.parse(text)                                  // 1
if (!obj || typeof obj !== 'object') throw ...                // 2
if (obj.app !== 'prd-create') throw ...                       // 3
if (!obj.draft || typeof obj.draft !== 'object') throw ...    // 4
const b = obj.draft.basic
if (!b || typeof b !== 'object' || typeof b.moduleName !== 'string') throw ...  // 5
```

补充规则：

- `formatVersion > 1` 时工具仅提示「该工程文件由更新版本导出，部分内容可能无法识别」，仍会导入。
- 导入后工具会把 `draft` 与默认结构做**顶层浅合并**兜底：缺失的顶层数组按 `[]` 处理、`basic` 缺失的键按默认值填充。
- **但数组内的行对象不会逐字段补全**：例如 `features[0]` 缺少 `acceptance`，渲染时会报错。因此每一行的字段都必须写全。

---

## 3. TypeScript 等价类型定义

```ts
export type SectionCode =
  | 'terms' | 'roles' | 'features' | 'pages' | 'datamodel'
  | 'api' | 'rules' | 'nfr' | 'checklist'

export interface BasicInfo {
  moduleName: string   // 模块中文名，必填
  moduleCode: string   // 模块英文编码，如 shop_list
  version: string      // 默认 v1.0
  owner: string        // 负责人，建议「姓名（角色）」
  docDate: string      // YYYY-MM-DD
  status: string       // 如 评审中 / 已发布
  background: string   // 业务背景
  goal: string         // 业务目标（尽量量化）
  inScope: string      // 范围内
  outScope: string     // 范围外
}

export interface Term { term: string; meaning: string }

export interface Role { role: string; desc: string; permission: string }

export type FeaturePriority = 'P0' | 'P1' | 'P2' | 'P3' | 'P4'

export interface Feature {
  name: string
  priority: FeaturePriority
  desc: string
  userStory: string
  acceptance: string[]
  remark: string
}

export interface Page {
  pageName: string; route: string; blocks: string
  interaction: string; validation: string; remark: string
}

export interface EntityField {
  name: string; type: string; required: boolean
  defaultValue: string; enumValues: string; desc: string
}

export interface Entity {
  entityName: string; tableName: string; desc: string; fields: EntityField[]
}

export interface Api {
  name: string; method: string; path: string; desc: string
  reqParams: string; reqExample: string; respExample: string; errorCodes: string
}

export interface StateTransition {
  current: string; event: string; next: string; remark: string
}

export interface Rule { name: string; desc: string }          // 业务规则
export interface ChecklistItem { name: string; desc: string } // 验收清单
export interface Risk { name: string; desc: string }          // 风险
export interface NfrItem { name: string; desc: string }       // 非功能需求

export interface PrdDraft {
  basic: BasicInfo
  terms: Term[]
  roles: Role[]
  features: Feature[]
  pages: Page[]
  entities: Entity[]
  apis: Api[]
  states: StateTransition[]
  rules: Rule[]
  checklist: ChecklistItem[]
  risks: Risk[]
  nfr: NfrItem[]
  sectionsEnabled: Record<SectionCode, boolean>
}

export interface PrdProjectFile {
  app: 'prd-create'
  formatVersion: number
  exportedAt: string
  moduleName: string
  draft: PrdDraft
}
```

---

## 4. `draft` 13 键总览

| 键 | 类型 | 无内容时 | 说明 |
| --- | --- | --- | --- |
| `basic` | object | 不可为空对象，10 键齐全 | 模块基础信息 |
| `terms` | `Term[]` | `[]` | 术语表 |
| `roles` | `Role[]` | `[]` | 角色与权限 |
| `features` | `Feature[]` | `[]` | 功能需求 |
| `pages` | `Page[]` | `[]` | 页面与交互 |
| `entities` | `Entity[]` | `[]` | 数据模型 |
| `apis` | `Api[]` | `[]` | 接口设计 |
| `states` | `StateTransition[]` | `[]` | 状态流转（与 `rules` 同属一个章节） |
| `rules` | `Rule[]` | `[]` | 业务规则 |
| `checklist` | `ChecklistItem[]` | `[]` | 验收清单（与 `risks` 同属一个章节） |
| `risks` | `Risk[]` | `[]` | 风险 |
| `nfr` | `NfrItem[]` | `[]` | 非功能需求 |
| `sectionsEnabled` | object | 9 个码齐全 | 章节输出开关 |

---

## 5. 章节顺序与开关（`sectionsEnabled`）

`draft.sectionsEnabled` 固定 9 个键，默认全 `true`；某章节无内容或用户要求精简时设 `false`。
键与 `draft` 数组的对应关系、以及文档渲染顺序如下：

| order | 章节码 | 章节标题 | 使用的 draft 键 | 渲染形态 |
| --- | --- | --- | --- | --- |
| 1 | `features` | 功能需求 | `features` | 表格汇总 + 逐条详情 |
| 2 | `datamodel` | 数据模型 | `entities` | 逐实体 + 字段表 |
| 3 | `api` | 接口设计 | `apis` | 表格汇总 + 逐接口详情 |
| 4 | `pages` | 页面与交互 | `pages` | 逐页面列表 |
| 5 | `roles` | 角色与权限 | `roles` | 表格 |
| 6 | `terms` | 术语表 | `terms` | 表格 |
| 7 | `rules` | 业务规则与状态机 | `rules` + `states` | 业务规则表 + 状态流转表 |
| 8 | `nfr` | 非功能需求 | `nfr` | 表格 |
| 9 | `checklist` | 验收清单与风险 | `checklist` + `risks` | 验收清单表 + 风险表 |

```json
"sectionsEnabled": {
  "terms": true, "roles": true, "features": true, "pages": true,
  "datamodel": true, "api": true, "rules": true, "nfr": true, "checklist": true
}
```

---

## 6. 行对象字段定义

### `basic`（对象，10 键）

| 键 | 类型 | 说明 / 示例 |
| --- | --- | --- |
| moduleName | string | 模块中文名，**必填非空**，用于文档标题与文件名，如 `售后管理` |
| moduleCode | string | 英文编码，如 `after_sale` |
| version | string | 默认 `v1.0` |
| owner | string | 「姓名（角色）」，如 `李婷（产品经理）` |
| docDate | string | `YYYY-MM-DD` |
| status | string | `评审中` / `已发布` 等 |
| background | string | 现状问题与动因 |
| goal | string | 目标，尽量量化 |
| inScope | string | 本期要做的内容清单 |
| outScope | string | 明确不做的内容 |

### `Term[]`：term / meaning
### `Role[]`：role / desc / permission
### `Feature[]`

| 键 | 类型 | 说明 |
| --- | --- | --- |
| name | string | 动宾短语，如 `发起售后申请` |
| priority | string | 枚举 `P0`/`P1`/`P2`/`P3`/`P4`（P0=核心链路） |
| desc | string | 做什么、覆盖哪些场景 |
| userStory | string | 「作为…，我希望…，以便…」 |
| acceptance | string[] | 验收标准数组，每项一条、可验证 |
| remark | string | 依赖/前置条件；无则 `""` |

### `Page[]`：pageName / route / blocks / interaction / validation / remark
### `Entity[]`

| 键 | 类型 | 说明 |
| --- | --- | --- |
| entityName | string | 帕斯卡命名，如 `AfterSaleOrder` |
| tableName | string | 下划线，如 `t_after_sale_order` |
| desc | string | 实体职责一句话 |
| fields | EntityField[] | 字段数组，见下 |

### `EntityField[]`

| 键 | 类型 | 说明 |
| --- | --- | --- |
| name | string | 字段名（下划线） |
| type | string | 数据库类型，如 `bigint`、`varchar(32)`、`decimal(10,2)`、`datetime` |
| required | boolean | 是否必填（`true`/`false`） |
| defaultValue | string | 默认值；无则 `""` |
| enumValues | string | 「值含义/值含义」，如 `0待支付/1已支付`；无则 `""` |
| desc | string | 字段含义、取值规则 |

### `Api[]`

| 键 | 类型 | 说明 |
| --- | --- | --- |
| name | string | 接口功能名 |
| method | string | 大写 HTTP 方法：GET/POST/PUT/PATCH/DELETE |
| path | string | 以 `/` 开头，路径参数 `{xxx}` |
| desc | string | 接口职责 |
| reqParams | string | 参数说明（来源、是否必填） |
| reqExample | string | **字符串**，内部是一段合法 JSON（换行 `\n`、引号 `\"`） |
| respExample | string | 同上，建议 `{"code":0,"data":{...}}` |
| errorCodes | string | `编码-说明`，多条用 `；` 分隔 |

### `StateTransition[]`：current / event / next / remark
### `Rule[]` / `ChecklistItem[]` / `Risk[]` / `NfrItem[]`：均为 name / desc

---

## 7. 默认值约定（工具端 `defaultData`）

- `basic.version` 默认 `v1.0`；`basic.docDate` 默认当天 `YYYY-MM-DD`。
- `nfr` 工具预置分类：`性能` / `安全` / `兼容性` / `数据量`（可自定义增删）。
- `sectionsEnabled` 9 个码默认全 `true`。
- 所有数组无内容时为 `[]`。

---

## 8. 通用约定（强制）

1. 键名必须与本文件**逐字一致**，禁止近义词（`desc` 不可写 `description`，`reqExample` 不可写 `requestExample`），禁止多余键。
2. 字符串字段无内容时为 `""`；**不允许 `null` / `undefined`**；数组无条目时为 `[]`。
3. 布尔字段（`required`、`sectionsEnabled` 的值、`formatVersion` 之外的数字）用原生字面量：`true`/`false`；`formatVersion` 用数字 `1`。
4. 顶层只能是 5 个元信息键；`basic`/`features` 等内容键**不得**出现在顶层。
5. 内容一律中文撰写（术语、代码、字段名保留英文原文）。
6. 单个文件只描述**一个业务模块**；多模块需分别产出多个文件。
7. 输出前按 SKILL.md 的「必检清单」自检，特别是
   `obj.app === 'prd-create' && typeof obj.draft.basic.moduleName === 'string'`。
