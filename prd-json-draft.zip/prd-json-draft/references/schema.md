# 工程文件（PrdProjectFile）字段级规范

> 本文件**自包含**，使用时无需访问 prd-create 项目源码。
> 结构契约（类型定义、校验规则、章节顺序、默认值）以 `format.md` 为准；
> 本文件侧重**内容撰写规范**（每个字段写什么、写到什么程度、示例与常见写法）。

## 顶层：工程文件外壳（必含 5 个键）

| 键 | 类型 | 说明 / 示例 |
| --- | --- | --- |
| app | string | 固定 `"prd-create"`，**区分大小写**；导入时严格比对，写成 `prd_create`/`PRD-Create` 都会导入失败 |
| formatVersion | number | 固定数字 `1`（当前 `PROJECT_FORMAT_VERSION`），不要写成字符串 |
| exportedAt | string | ISO8601 UTC 时间，如 `2026-09-04T07:30:00.000Z` |
| moduleName | string | 与 `draft.basic.moduleName` **逐字一致** |
| draft | object | 完整的 `PrdDraft`，含下文 13 个键 |

最小可导入骨架（其余内容同理放在 `draft` 内）：

```json
{
  "app": "prd-create",
  "formatVersion": 1,
  "exportedAt": "2026-09-04T07:30:00.000Z",
  "moduleName": "售后管理",
  "draft": {
    "basic": { "moduleName": "售后管理" },
    "terms": [], "roles": [], "features": [], "pages": [],
    "entities": [], "apis": [], "states": [], "rules": [],
    "checklist": [], "risks": [], "nfr": [], "sectionsEnabled": {}
  }
}
```

### 导入校验规则（详见 `format.md` 第 2 节）

1. `JSON.parse` 通过，且结果是对象（非数组、非 null）；
2. `app === 'prd-create'`（严格相等）；
3. `draft` 是对象；
4. `draft.basic` 是对象且 `draft.basic.moduleName` 是字符串。

任一不满足即抛错。**最常见的失败原因**：少了工程外壳，把 `basic`/`features` 等 13 键直接放在顶层（裸 `PrdDraft`），工具会提示「该文件不是本工具导出的 PRD 工程文件」。

---

# draft 内部结构（PrdDraft）撰写规范

`draft` 内 13 个键与章节归属映射如下（下表顺序即文档渲染顺序）：

| 章节标题（目录/正文） | 章节码 sectionsEnabled | JSON 键 | 正文渲染位置 |
| --- | --- | --- | --- |
| 功能需求 | features | `features` | 表格汇总 + 逐条详情 |
| 数据模型 | datamodel | `entities` | 逐实体 + 字段表 |
| 接口设计 | api | `apis` | 表格汇总 + 逐接口详情 |
| 页面与交互 | pages | `pages` | 逐页面列表 |
| 角色与权限 | roles | `roles` | 表格 |
| 术语表 | terms | `terms` | 表格 |
| 业务规则与状态机 | rules | `rules` + `states` | 业务规则表 + 状态流转表 |
| 非功能需求 | nfr | `nfr` | 表格 |
| 验收清单与风险 | checklist | `checklist` + `risks` | 验收清单表 + 风险表 |

约定：所有字符串字段无内容时为 `""`；无条目的数组为 `[]`；不输出 `null`。

## basic（对象，必含 10 个键）

| 键 | 类型 | 说明 / 示例 |
| --- | --- | --- |
| moduleName | string | 模块中文名，必填，用于文档标题与工程文件名，如 `售后管理` |
| moduleCode | string | 模块英文编码，如 `after_sale` |
| version | string | 默认 `v1.0` |
| owner | string | 负责人，建议「姓名（角色）」，如 `李婷（产品经理）` |
| docDate | string | `YYYY-MM-DD` |
| status | string | 文档状态，如 `评审中` / `已发布` |
| background | string | 业务背景，说明现状问题与动因 |
| goal | string | 业务目标，尽量量化（时效、转化、人力等） |
| inScope | string | 范围内：本期要做的内容清单 |
| outScope | string | 范围外：明确不做的内容 |

## terms：Term[]（每行：term / meaning）

| 键 | 说明 |
| --- | --- |
| term | 术语名 |
| meaning | 一句话定义，无歧义 |

## roles：Role[]（每行：role / desc / permission）

| 键 | 说明 |
| --- | --- |
| role | 角色名，如 `客服` |
| desc | 该角色在本模块内的职责 |
| permission | 权限边界（能做什么 / 不能做什么） |

## features：Feature[]（每行：name / priority / desc / userStory / acceptance / remark）

| 键 | 类型 | 说明 |
| --- | --- | --- |
| name | string | 功能名，动宾短语，如 `发起售后申请` |
| priority | string | 枚举：`P0`/`P1`/`P2`/`P3`/`P4`。P0=核心链路，P1=重要，其余递减 |
| desc | string | 功能描述：做什么、覆盖什么场景 |
| userStory | string | 「作为…，我希望…，以便…」句式 |
| acceptance | string[] | 验收标准，每项一条、可验证（含关键边界：幂等、超时、金额规则等） |
| remark | string | 依赖、前置条件、风险提示；无则 `""` |

## pages：Page[]（每行：pageName / route / blocks / interaction / validation / remark）

| 键 | 说明 |
| --- | --- |
| pageName | 页面名，如 `售后列表` |
| route | 前端路由，如 `/aftersales`、`/aftersales/:id` |
| blocks | 页面区块组成，用顿号/逗号分隔列举 |
| interaction | 交互与状态变化：点击/筛选/弹窗/跳转等 |
| validation | 表单与操作的校验规则 |
| remark | 备注，无则 `""` |

## entities：Entity[]（每行：entityName / tableName / desc / fields[]）

| 键 | 说明 |
| --- | --- |
| entityName | 实体名（帕斯卡，如 `AfterSaleOrder`） |
| tableName | 表名（下划线，如 `t_after_sale_order`） |
| desc | 实体职责一句话 |
| fields | EntityField[]，见下 |

### EntityField[]（每行：name / type / required / defaultValue / enumValues / desc）

| 键 | 类型 | 说明 |
| --- | --- | --- |
| name | string | 字段名（下划线） |
| type | string | 数据库类型，如 `bigint`、`varchar(32)`、`decimal(10,2)`、`datetime` |
| required | boolean | 是否必填 |
| defaultValue | string | 默认值；无则 `""`（主键/时间可写 `NULL` 需谨慎，通常留空串） |
| enumValues | string | 枚举「值含义/值含义」，如 `0待支付/1已支付/2已发货`；无则 `""` |
| desc | string | 字段含义，含取值规则/生成方式等 |

主键、唯一业务号、金额、状态等关键字段都要列出并写清 desc。

## apis：Api[]（每行：name / method / path / desc / reqParams / reqExample / respExample / errorCodes）

| 键 | 类型 | 说明 |
| --- | --- | --- |
| name | string | 接口功能名 |
| method | string | 大写 HTTP 方法：GET/POST/PUT/PATCH/DELETE |
| path | string | 以 `/` 开头，路径参数用 `{xxx}`，如 `/api/aftersales/{order_no}` |
| desc | string | 接口职责一句话 |
| reqParams | string | 请求参数说明（来源、是否必填），可用多行 |
| reqExample | string | **字符串**，内含一段合法 JSON。换行转义 `\n`、引号转义 `\"`；无则 `""` |
| respExample | string | 同上；建议统一外层 `{"code":0,"data":{...}}` |
| errorCodes | string | 错误码，`编码-说明` 用 `；` 分隔，如 `4040-订单不存在；4030-无权限查看` |

## states：StateTransition[]（每行：current / event / next / remark）

| 键 | 说明 |
| --- | --- |
| current | 当前状态 |
| event | 触发事件（谁触发/什么动作），需具体 |
| next | 目标状态 |
| remark | 补充说明（回调驱动、超时、回填单号等）；无则 `""` |

要求：current/next 的状态名词与实体 `status` 字段的枚举值口径一致；同状态可多行（不同事件）。

## rules：Rule[]（每行：name / desc）

| 键 | 说明 |
| --- | --- |
| name | 规则名，短语式，如 `金额一致性` |
| desc | 规则内容：约束条件 + 触发处理，须明确可落地 |

## checklist：ChecklistItem[]（每行：name / desc）

验收/自检条目，聚焦易错点：幂等、超时、并发、权限、脱敏、边界值。

## risks：Risk[]（每行：name / desc）

| 键 | 说明 |
| --- | --- |
| name | 风险/待确认问题名，如 `支付回调延迟` |
| desc | 现象、影响与应对/补偿方案 |

## nfr：NfrItem[]（每行：name / desc）

预置分类习惯：`性能` / `安全` / `兼容性` / `数据量`（可自定义增删）。只列有量化指标的条目，例如：

- `性能`：列表 P95 响应 < 300ms
- `安全`：敏感字段加密与脱敏展示
- `兼容性`：浏览器/移动端版本范围
- `数据量`：日均/年增长量、存储与归档策略

## sectionsEnabled：Record<SectionCode, boolean>

键（固定 9 个）：`terms`、`roles`、`features`、`pages`、`datamodel`、`api`、`rules`、`nfr`、`checklist`。
默认全 `true`；某章节内容为空或用户要求精简时对应设为 `false`。
